#include "stm32f4xx_conf.h"
#include "stm32f4xx_usart.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_rcc.h"
#include "stm32f4xx_cryp.h"

void uart_init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	
	USART_InitStructure.USART_BaudRate = 115200;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	
	/* Enable GPIO clock */
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC | RCC_AHB1Periph_GPIOC, ENABLE);
	
	/* Enable UART clock */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
	
	/* Connect PXx to USARTx_Tx*/
	GPIO_PinAFConfig(GPIOC, GPIO_PinSource10, GPIO_AF_USART3);
	
	/* Connect PXx to USARTx_Rx*/
	GPIO_PinAFConfig(GPIOC, GPIO_PinSource11, GPIO_AF_USART3);
	
	/* Configure USART Tx as alternate function  */
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	/* Configure USART Rx as alternate function  */
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	/* USART configuration */
	USART_Init(USART3, &USART_InitStructure);
	
	/* Enable USART */
	USART_Cmd(USART3, ENABLE);
}
//Sends str through the UART
int uart_write(char* str)
{
	while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
	while(*str!='\0')
	{		
		USART_SendData(USART3, (uint8_t)*str);
		
		while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
		str++;
	}
	return 0;
}


void uart_wait(void)
{
	while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
	USART3->DR = ('W' & (uint16_t)0x01FF);
	while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
	USART3->DR = ('A' & (uint16_t)0x01FF);
	while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
	USART3->DR = ('I' & (uint16_t)0x01FF);
	while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
	USART3->DR = ('T' & (uint16_t)0x01FF);
	while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
	USART3->DR = (' ' & (uint16_t)0x01FF);
	while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
}

//Reads the uart to str
int uart_readstr(char* str)
{
	uint8_t c;
	
	do
	{
		while(USART_GetFlagStatus(USART3, USART_FLAG_RXNE)==RESET);
		c = USART_ReceiveData(USART3);
		*str = c;
		str++;
	}
	while( c != '\r');
	
	*str = '\0';
	
	return 0;
}

void trigger_init(void)
{
	GPIO_InitTypeDef gpio_init;
	GPIO_StructInit(&gpio_init);	
	// gpio_init.GPIO_Pin  = GPIO_Pin_6; //original default (works on almost all)
	gpio_init.GPIO_Pin  = GPIO_Pin_All;
	gpio_init.GPIO_Mode = GPIO_Mode_OUT;
	gpio_init.GPIO_OType = GPIO_OType_PP;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	GPIO_Init(GPIOA,&gpio_init);
	
	// RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
	// GPIO_Init(GPIOB,&gpio_init);
	
}

char uart_getc(void)
{
	while(USART_GetFlagStatus(USART3, USART_FLAG_RXNE)==RESET);	
	return USART_ReceiveData(USART3);
}

void cryp_init(void)
{
	CRYP_InitTypeDef Crypt_init;
	CRYP_KeyInitTypeDef CRYP_key;
	
	CRYP_StructInit(&Crypt_init);
	CRYP_DeInit();	
	CRYP_KeyStructInit(&CRYP_key);
	RCC_AHB2PeriphClockCmd(RCC_AHB2Periph_CRYP, ENABLE);
	
	Crypt_init.CRYP_AlgoDir=CRYP_AlgoDir_Encrypt;
	Crypt_init.CRYP_AlgoMode=CRYP_AlgoMode_AES_ECB;
	Crypt_init.CRYP_DataType=CRYP_DataType_32b;
	Crypt_init.CRYP_KeySize=CRYP_KeySize_128b;
	CRYP_Init(&Crypt_init);
	
//	CRYP_key.CRYP_Key0Left = 0x10101010;
//	CRYP_key.CRYP_Key0Right = 0x32323232;
//	CRYP_key.CRYP_Key1Left = 0x63636363;
//	CRYP_key.CRYP_Key1Right = 0x24242424;
//	CRYP_key.CRYP_Key2Left = 0x25252525;
//	CRYP_key.CRYP_Key2Right = 0x16161616;
//	CRYP_key.CRYP_Key3Left = 0x88888888;
//	CRYP_key.CRYP_Key3Right = 0x98989898;


	
	//Key = [K2L K2R K3L K3R]
	CRYP_key.CRYP_Key2Left = 0x01234567;
	CRYP_key.CRYP_Key2Right = 0x89ABCDEF;
	CRYP_key.CRYP_Key3Left = 0xDEADBEEF;
	CRYP_key.CRYP_Key3Right = 0x12344321;
	
	CRYP_KeyInit(&CRYP_key);
	
	CRYP->CR |= CRYP_CR_CRYPEN;
	CRYP_FIFOFlush();	
}

void uart_ok(void)
{
	while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
	USART3->DR = ('O' & (uint16_t)0x01FF);
	while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
	USART3->DR = ('K' & (uint16_t)0x01FF);
	while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
}

void uart_aa(void)
{
	while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
	USART3->DR = ('A' & (uint16_t)0x01FF);
	while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
	USART3->DR = ('A' & (uint16_t)0x01FF);
	while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
}

void uart_rr(void)
{
	while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
	USART3->DR = ('R' & (uint16_t)0x01FF);
	while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
	USART3->DR = ('R' & (uint16_t)0x01FF);
	while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
}
