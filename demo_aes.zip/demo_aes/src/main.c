#include <stdio.h>
#include "stm32f4xx.h"
#include "stm32f4xx_cryp.h"
#include "com.h"
#include "ram_code.h"
#include "stm32f4x_macro_soc.h"

#define PLL_OUTPUT_FREQUENCY 40

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{

}
#endif

int main(void)
{		
	char c;
	uint32_t out[4],in[4];
	uint8_t *ptr;
	uint8_t i;
	int a = SystemCoreClock;
	Soc_SetSysClockToPLL(PLL_OUTPUT_FREQUENCY,8,RCC_PLLSource_HSE);
	SystemCoreClockUpdate();
	
	
	uart_init();
	trigger_init();
	cryp_init();
	
	out[0] = 0x00112233;
	out[1] = 0x44556677;
	out[2] = 0x8899AABB;
	out[3] = 0xCCDDEEFF;
	
	while(1)
	{
		//Wait for UART command
		c = uart_getc();	
	
		if(c=='G')
		{ 
			in[0] = out[0];
			in[1] = out[1];
			in[2] = out[2];
			in[3] = out[3];
			
			//for(i=0;i<10;i++);
			
			// GPIOA->BSRRL = GPIO_Pin_All;
			// GPIOB->BSRRL = GPIO_Pin_All;
			//for(i=0;i<1;i++);
			// GPIOA->BSRRH = GPIO_Pin_All;
			// GPIOB->BSRRH = GPIO_Pin_All;
			//for(i=0;i<2;i++);
			//for(i=0;i<3;i++);
			GPIOA->BSRRL = GPIO_Pin_All;
			//for(i=0;i<100;i++);
			CRYP->DR = in[0];
			CRYP->DR = in[1];
			CRYP->DR = in[2];
			CRYP->DR = in[3];
			//for(i=0;i<100;i++);
			
//			CRYP->DR = 0x00000001;
//			CRYP->DR = 0x00000002;
//			CRYP->DR = 0x00000003;
//			CRYP->DR = 0x00000004;
			while((CRYP->SR & CRYP_FLAG_BUSY) != 0);
			GPIOA->BSRRH = GPIO_Pin_All;
			//GPIOA->BSRRH = GPIO_Pin_6;

			//for(i=0;i<100;i++);		
			
			out[0] = CRYP->DOUT;
			out[1] = CRYP->DOUT;
			out[2] = CRYP->DOUT;
			out[3] = CRYP->DOUT;
			
			uart_ok();
		}
		if(c=='R')
		{
			for(i=0;i<4;i++)
			{
				ptr = (uint8_t*)&in[i];
				ptr += 3;
				
				USART3->DR = (*ptr & (uint16_t)0x01FF);
				while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
				ptr--;
				USART3->DR = (*ptr & (uint16_t)0x01FF);
				while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
				ptr--;
				USART3->DR = (*ptr & (uint16_t)0x01FF);
				while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
				ptr--;
				USART3->DR = (*ptr & (uint16_t)0x01FF);
				while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
			}
			for(i=0;i<4;i++)
			{
				ptr = (uint8_t*)&out[i];
				ptr += 3;
				
				USART3->DR = (*ptr & (uint16_t)0x01FF);
				while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
				ptr--;
				USART3->DR = (*ptr & (uint16_t)0x01FF);
				while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
				ptr--;
				USART3->DR = (*ptr & (uint16_t)0x01FF);
				while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
				ptr--;
				USART3->DR = (*ptr & (uint16_t)0x01FF);
				while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
			}
		}
		
		if (c == 'F')
		{
			uart_aa();
			NVIC_SystemReset();
		}
	}
}
