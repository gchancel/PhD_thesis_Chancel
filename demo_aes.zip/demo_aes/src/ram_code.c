#include "stm32f4xx.h"
#include "com.h"

void ram_aes(char c)
{
		uint32_t out[4];
		uint8_t *ptr;
		uint8_t i;
	
		if(c=='G')
		{			
			GPIOA->BSRRL = GPIO_Pin_6;
			
			CRYP->DR = 0x00112233;
			CRYP->DR = 0x44556677;
			CRYP->DR = 0x8899AABB;
			CRYP->DR = 0xCCDDEEFF;
					
			GPIOA->BSRRH = GPIO_Pin_6;
					
			out[0] = CRYP->DOUT;
			out[1] = CRYP->DOUT;
			out[2] = CRYP->DOUT;
			out[3] = CRYP->DOUT;
			
			for(i=0;i<4;i++)
			{
				ptr = (uint8_t*)&out[i];
				
				USART3->DR = (*ptr & (uint16_t)0x01FF);
				ptr++;
				USART3->DR = (*ptr & (uint16_t)0x01FF);
				ptr++;
				USART3->DR = (*ptr & (uint16_t)0x01FF);
				ptr++;
				USART3->DR = (*ptr & (uint16_t)0x01FF);
			}
		}
		
		
}
