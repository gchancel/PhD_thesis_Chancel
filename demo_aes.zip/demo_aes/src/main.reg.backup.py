#include <stdio.h>
#include "stm32f4xx.h"
#include "stm32f4xx_cryp.h"
#include "com.h"
#include "ram_code.h"
#include "stm32f4x_macro_soc.h"

#define PLL_OUTPUT_FREQUENCY 40

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{

}
#endif

int main(void)
{		
	char c0;
	char c1;
	char c2;
	char c3;
	uint32_t u0;
	
	char c4;
	char c5;
	char c6;
	char c7;
	uint32_t u1;
	
	uint32_t uR;
	
	register uint32_t R8 __asm("r8");
	char R0img;
//	char string[5];
//	uint32_t out[4],in[4];
//	uint8_t *ptr;
	uint32_t i;
	uint32_t j;
	int a = SystemCoreClock;
	Soc_SetSysClockToPLL(PLL_OUTPUT_FREQUENCY,8,RCC_PLLSource_HSE);
	SystemCoreClockUpdate();
	R8 = 0;
	uart_init();
	trigger_init();
	GPIOA->BSRRH = GPIO_Pin_All; //pin reset

	//c = uart_getc();
	while (1)
	{
		R8 = 0;
		c0 = uart_getc();
		c1 = uart_getc();
		c2 = uart_getc();
		c3 = uart_getc();
		u0 = (c0 << 24) | (c1 << 16) | (c2 << 8) | c3;
		
//		c4 = uart_getc();
//		c5 = uart_getc();
//		c6 = uart_getc();
//		c7 = uart_getc();
//		u1 = (c4 << 24) | (c5 << 16) | (c6 << 8) | c7;
//		
//		uR = u0 + u1;
		
		for (j = 0; j < 128; j++); //128 loops before doing again
//		c0 = 'G';
//		c1 = 'E';
//		c2 = 'O';
//		c3 = 'F';
		GPIOA->BSRRL = GPIO_Pin_All; //pin set
		for (j = 0; j < 16; j++); //wait 4 loops
		for (i = 0; i < 8; i++)
		{
			//R8 = uR;
			R8 = u0;
			R8 = 0;
		}
//		R8 = (c0 << 24) | (c1 << 16) | (c2 << 8) | c3; //write buffer value into register
//		R8 = 0xFFFFFFFF; //write buffer value into register
		for (j = 0; j < 16; j++); //wait 4 loops
		GPIOA->BSRRH = GPIO_Pin_All; //pin reset
		for (j = 0; j < 128; j++); //128 loops before doing again
	}
}
