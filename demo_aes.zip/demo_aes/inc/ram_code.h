#ifndef RAM_CODE
#define RAM_CODE

void ram_aes(char c);

#endif //RAM_CODE
