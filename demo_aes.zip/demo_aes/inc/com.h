#ifndef UART_H
#define UART_H

void uart_init(void);
int uart_write(char* str);
int uart_readstr(char* str);
char uart_getc(void);
void trigger_init(void);
void cryp_init(void);
void rng_init(void);
void uart_ok(void);
void uart_aa(void);
void uart_rr(void);
void uart_wait(void);
#endif //UART_H
